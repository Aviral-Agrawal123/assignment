package lab4.assignments;

import java.util.Scanner;

public class SumOfTheCubes {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the n digit number");
		int number = sc.nextInt();
		SumOfTheCubes obj = new SumOfTheCubes();
		obj.cubesOfDigits(number);
		sc.close();
	}
	
	// method to calculate the sum of the cubes of a digit
	public void cubesOfDigits(int number) {
		int mod,sumOfCubes=0;
		while(number!=0) {
			mod=number%10;
			sumOfCubes=sumOfCubes+(mod*mod*mod);
			number=number/10;
		}
		System.out.println("Sum of the cubes of the digits of a number is : "+sumOfCubes);
	}
}

