package lab3.assignments;

import java.util.Arrays;
import java.util.Scanner;


public class ReverseNumbersInArray {
	
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		ReverseNumbersInArray obj = new ReverseNumbersInArray();
		System.out.println("Enter the size of an array");
		int size = sc.nextInt();
		int unsortedArray[] = new int[size];
		for(int i=0; i<size; i++)
			unsortedArray[i] = sc.nextInt();
		int sortedArray[] = obj.getSorted(unsortedArray);
		System.out.println("Sorted array is :");
		for(int i=0; i<size; i++)
			System.out.println(sortedArray[i]);
		sc.close();
	}
	
	//method to reverse and sort an array
	public int[] getSorted(int unsortedArray[])
	{
		String num="";
		int number=0,mod;
		int length=unsortedArray.length;
		int[] array =new int[length];
		
		//reverse the numbers in an array
		for(int i=0;i<length;i++) {
			number=unsortedArray[i];
			while(number!=0) {
				mod=number%10;
				num=num+mod;
				number=number/10;
			}
			array[i]=Integer.parseInt(num);
			num="";
			
		}
		// sort the array
		Arrays.sort(array);
		return array;
		
	}

}

