package lab7.assignments;

import java.util.HashMap;
import java.util.Scanner;

public class NumberOfLinesPresentInArray {
	
	@SuppressWarnings("rawtypes")
	public static void main(String[] args)  { 
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of characters you want to enter");
        int length = sc.nextInt();
        char charArray[] = new char[length]; 
        for(int i=0; i<length; i++)
        	charArray[i] = sc.next().charAt(0);
        HashMap map = new HashMap();
        map  = countCharacter(charArray); 
        System.out.println(map);
        sc.close();
    }  
	  
	// method to count the occurrence of characters and return the values using HashMap
    @SuppressWarnings({ "rawtypes", "unused", "unchecked" })
	static HashMap countCharacter(char charArray[])   { 
        
    	HashMap map = new HashMap();
        int len = charArray.length;
        int length=charArray.length;
		int counter=0;
		for(int i=0; i<length; i+=counter) {
			if(i>=length)
				System.exit(0);
			counter=0;
			char character=charArray[i];
			for(int j=0; j<length; j++) {
					if(character==charArray[j])
						counter++;
					map.put(character, counter);
			}
		}
		return map; 
    } 
}
