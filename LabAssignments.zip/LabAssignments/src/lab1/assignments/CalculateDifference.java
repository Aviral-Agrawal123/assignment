package lab1.assignments;

import java.util.Scanner;

public class CalculateDifference {

	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the value of number");
		int number=sc.nextInt();
		CalculateDifference obj = new CalculateDifference();
		int difference = obj.calculateDifference(number);
		System.out.println("The difference is "+difference);
		sc.close();
	}
	// method to calculate the difference of sum of squares and square of sum of n numbers
	public int calculateDifference(int n){
		int sumOfSquares=0,squareOfSum=0;
		for(int i=1 ; i<=n; i++){
			sumOfSquares=sumOfSquares+(i*i);
			squareOfSum=squareOfSum+i;
		}
		squareOfSum=squareOfSum*squareOfSum;
		return sumOfSquares-squareOfSum;
	}
}
